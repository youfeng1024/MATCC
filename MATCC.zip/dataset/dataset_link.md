Qlib stock data instruments:

```
https://github.com/chenditc/investment_data/releases
```

Published CSI300 and CSI800 dataset with preprocessing in the paper and README.md:

```
https://pan.baidu.com/s/15gt3FcnwqTBAy5oPbzhOsA?pwd=1234
```
